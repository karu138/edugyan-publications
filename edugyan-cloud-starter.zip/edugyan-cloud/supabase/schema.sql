-- Edugyan Publications Cloud Database (Supabase PostgreSQL)
create extension if not exists pgcrypto;
create type public.app_role as enum ('admin','executive','accounts');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '', role public.app_role not null default 'executive',
 territory text, created_at timestamptz not null default now()
);
create table public.schools (
 id uuid primary key default gen_random_uuid(), name text not null,
 society text, address text, area text, pin_code text, phone text, mobile text,
 email text, correspondent text, authorized_person text,
 assigned_executive uuid references public.profiles(id),
 created_by uuid not null references auth.users(id), created_at timestamptz not null default now()
);
create table public.purchase_orders (
 id uuid primary key default gen_random_uuid(), po_number text unique,
 school_id uuid not null references public.schools(id),
 created_by uuid not null references auth.users(id), executive_id uuid references public.profiles(id),
 order_date date not null default current_date, dispatch_date date,
 gross_amount numeric(12,2) not null default 0 check(gross_amount>=0),
 discount_percent numeric(5,2) not null default 0 check(discount_percent between 0 and 100),
 discount_amount numeric(12,2) generated always as (gross_amount*discount_percent/100) stored,
 net_amount numeric(12,2) generated always as (gross_amount*(1-discount_percent/100)) stored,
 amount_paid numeric(12,2) not null default 0 check(amount_paid>=0),
 status text not null default 'Pending' check(status in ('Pending','Confirmed','Dispatched','Delivered')),
 transport_provider text, courier_provider text, notes text, created_at timestamptz not null default now()
);
create table public.purchase_order_lines (
 id uuid primary key default gen_random_uuid(), purchase_order_id uuid not null references public.purchase_orders(id) on delete cascade,
 class_name text not null, series text not null, mrp numeric(12,2) not null check(mrp>=0),
 set_quantity integer not null check(set_quantity>=0), created_at timestamptz not null default now()
);
create table public.payment_receipts (
 id uuid primary key default gen_random_uuid(), purchase_order_id uuid not null references public.purchase_orders(id) on delete cascade,
 amount numeric(12,2) not null check(amount>0), receipt_date date not null default current_date,
 payment_method text, reference_number text, notes text, entered_by uuid not null references auth.users(id), created_at timestamptz not null default now()
);
create table public.executive_assignments (
 id uuid primary key default gen_random_uuid(), executive_id uuid not null references public.profiles(id) on delete cascade,
 school_id uuid not null references public.schools(id) on delete cascade,
 unique(executive_id,school_id)
);
create or replace function public.current_role() returns public.app_role language sql stable security definer set search_path=public
as $$ select role from public.profiles where id=auth.uid() $$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_role()='admin',false) $$;
create or replace function public.can_access_school(sid uuid) returns boolean language sql stable security definer set search_path=public
as $$ select public.is_admin() or exists(select 1 from public.schools s where s.id=sid and (s.created_by=auth.uid() or s.assigned_executive=auth.uid())) or exists(select 1 from public.executive_assignments ea where ea.school_id=sid and ea.executive_id=auth.uid()) $$;
-- Auto-create a profile on signup. New users default to executive; an administrator must promote the first account.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id,full_name,role) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),'executive'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;\nalter table public.schools enable row level security;
alter table public.purchase_orders enable row level security;
alter table public.purchase_order_lines enable row level security;
alter table public.payment_receipts enable row level security;
alter table public.executive_assignments enable row level security;
create policy "profiles self or admin read" on public.profiles for select using(id=auth.uid() or public.is_admin());
create policy "admin manages profiles" on public.profiles for all using(public.is_admin()) with check(public.is_admin());
create policy "school read permitted" on public.schools for select using(public.is_admin() or created_by=auth.uid() or assigned_executive=auth.uid() or exists(select 1 from public.executive_assignments ea where ea.school_id=id and ea.executive_id=auth.uid()));
create policy "school create authenticated" on public.schools for insert to authenticated with check(created_by=auth.uid());
create policy "admin or creator updates school" on public.schools for update using(public.is_admin() or created_by=auth.uid()) with check(public.is_admin() or created_by=auth.uid());
create policy "admin deletes school" on public.schools for delete using(public.is_admin());
create policy "orders read permitted" on public.purchase_orders for select using(public.is_admin() or created_by=auth.uid() or public.can_access_school(school_id));
create policy "orders create permitted" on public.purchase_orders for insert to authenticated with check(created_by=auth.uid() and public.can_access_school(school_id));
create policy "admin/accounts update orders" on public.purchase_orders for update using(public.is_admin() or public.current_role()='accounts') with check(public.is_admin() or public.current_role()='accounts');
create policy "admin delete orders" on public.purchase_orders for delete using(public.is_admin());
create policy "lines read via order" on public.purchase_order_lines for select using(exists(select 1 from public.purchase_orders po where po.id=purchase_order_id and public.can_access_school(po.school_id)));
create policy "lines insert via order" on public.purchase_order_lines for insert to authenticated with check(exists(select 1 from public.purchase_orders po where po.id=purchase_order_id and po.created_by=auth.uid()));
create policy "admin update lines" on public.purchase_order_lines for all using(public.is_admin()) with check(public.is_admin());
create policy "receipts read permitted" on public.payment_receipts for select using(exists(select 1 from public.purchase_orders po where po.id=purchase_order_id and (public.is_admin() or public.current_role()='accounts' or public.can_access_school(po.school_id))));
create policy "accounts or admin add receipts" on public.payment_receipts for insert to authenticated with check(entered_by=auth.uid() and (public.is_admin() or public.current_role()='accounts'));
create policy "admin manages receipts" on public.payment_receipts for all using(public.is_admin()) with check(public.is_admin());
create policy "admin manages assignments" on public.executive_assignments for all using(public.is_admin()) with check(public.is_admin());
create index schools_created_by_idx on public.schools(created_by);
create index po_school_idx on public.purchase_orders(school_id);
create index po_date_idx on public.purchase_orders(order_date);
create index receipts_po_idx on public.payment_receipts(purchase_order_id);
