# Edugyan Publications — Cloud Management App

This is a **full-stack starter**, not a deployed live site yet. It uses Next.js + Supabase Auth/Postgres and is designed for permanent cloud hosting and multi-device use.

## Deploy checklist
1. Create a Supabase project at https://supabase.com.
2. In Supabase → SQL Editor, run `supabase/schema.sql`.
3. In Supabase → Authentication → Providers → Email, configure signup/confirmation to your preference.
4. Copy Project URL and anon/public key from Project Settings → API.
5. Copy `.env.example` to `.env.local` and fill in those values. Never put a `service_role` key in browser code.
6. Install Node.js 20+, then in this folder run:
   ```bash
   npm install
   npm run dev
   ```
7. Deploy to https://vercel.com by importing the Git repository. Add the two `NEXT_PUBLIC_SUPABASE_*` environment variables in Vercel project settings and deploy.
8. Create your first account. In Supabase SQL Editor, promote that account to admin:
   ```sql
   update public.profiles set role='admin' where id=(select id from auth.users where email='YOUR_ADMIN_EMAIL');
   ```
9. Create executive/accounts users through Supabase Auth; change their role in `public.profiles`. Assign territories/schools through `executive_assignments`.

## Important development status
- Included: Supabase Auth sign-in/sign-up, cloud school listing/registration, basic PO entry/list, database schema and row-level security policies.
- Not yet finished: complete original product-line PO form, editing/deleting workflows, payment receipt UI, role-aware admin screens, executive invite/reset flows, complete reports, print-ready PO, CSV/backup UX, and robust validation/audit logs.
- The uploaded original static HTML is preserved as `original-dashboard.html` for reference.
- Do not enter real customer data until you have deployed, configured roles, tested RLS, and enabled backups.
